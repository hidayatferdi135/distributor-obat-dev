<html class="fixed sidebar-left-collapsed">
	<head>  
		<meta charset="UTF-8"> 
		<link rel="shortcut icon" href="<?php echo base_url()?>/assets/images/favicon.png" type="image/ico">   
		<title>PT Airlangga sentral internasional</title>    
		<meta name="author" content="Paber"> 
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/bootstrap-datepicker/css/datepicker3.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>/assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/stylesheets/theme.css" /> 
		<link rel="stylesheet" href="<?php echo base_url()?>assets/stylesheets/skins/default.css" /> 
		<link rel="stylesheet" href="<?php echo base_url()?>assets/stylesheets/theme-custom.css"> 
		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/pnotify/pnotify.custom.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/vendor/isotope/jquery.isotope.css" />
		<script src="<?php echo base_url()?>assets/vendor/modernizr/modernizr.js"></script>  
	</head>
    <body style="background:white;">
        
    <table class="table table-condensed">
    <tr>
        <td width="50%"><h3><b>PT. Airlangga Sentral Internasional Asia</b></h3>
		<br><small>Kelurahan Kawangrejo Mumbulsari Jember</small>
		<br><small>FP.01.04/IV/0045-e/2019</small></td>
        <td></td>
        <td align="right"><h3><b>Faktur Pembelian</b></h3></td>
    </tr>
    <tr>
        <td>
            <table class="table table-borderless" style=" border: 1px solid black;">
                <tr>
                    <td>Nomor</td><td>:</td><td><?="JBR-".$penjualan?></td>
                </tr>
                <tr>
                    <td>Tanggal</td><td>:</td><td><?=date('d M Y')?></td>
                </tr>
                <tr>
                    <td>Seller</td><td>:</td><td><?=$this->session->userdata('nama_admin')?></td>
                </tr>
                <tr>
                    <td>Status Pembelian</td><td>:</td><td><?=$status?></td>
                </tr>
            </table>
        </td>
        <td></td>
        <td>
            <table class="table table-borderless" style=" border: 1px solid black;">
                <?php
                foreach ($apoteker as $key) {
                    ?>
				<tr>
                    <td>Kepada</td><td>:</td><td><?=ucwords(strtolower($key['nama_pembeli']))?>
												<br><?=$key['no_npwp']?>
					</td>
                </tr>
				<?php
					}
				?>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="3">
            <table class="table table-bordered" style=" border: 1px solid black;">
                <tr>
                    <th>BET/Exp</th>
                    <th>Jumlah</th>
                    <th>Nama Produk</th>
                    <th>Harga/Satuan</th>
                    <th>Diskon</th>
                    <th>Total</th>
                </tr>
            
            <?php
                $toak = 0;
                foreach ($keranjang as $key) {
                    ?>
                <tr>
                    <td><?=$key['no_bet']."/".date('d M Y', strtotime($key['tgl_expired']))?></td>
                    <td><?=$key['kuantiti']?></td>
                    <td><?=$key['nama_item']?></td>
                    <td><?=$key['harga']?></td>
                    <td><?=$key['diskon']?></td>
                    <td align="right"><?=rupiah($key['total'])?></td>
                </tr>

            <?php
                $toak += $key['total'];
                $ppn = $toak*10/100;
                $end = $toak+$ppn;
            }
            ?>
        </table>
        </td>
    </tr>
    <tr>
        <td>
            <table class="table table-borderless" style=" border: 1px solid black;">
                <tr>
                    <td>Terbilang</td><td>:</td><td><?=terbilang($end)?></td>
                </tr>
            </table>
        </td>
        <td></td>
        <td>
            <table class="table table-borderless" style=" border: 1px solid black;">
                <tr>
                    <td>Total</td><td>:</td><td align="right"><?=rupiah($toak)?></td>
                </tr>
                <tr>
                    <td>PPN</td><td>:</td><td align="right"><?=rupiah($ppn)?></td>
                </tr>
                <tr>
                    <td>Total Akhir</td><td>:</td><td align="right"><?=rupiah($end)?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><?php
                foreach ($apoteker as $key) {
                    ?>
        <table class="table table-borderless">
            <tr style="margin-bottom:50px;">
                <td align="center">Penerima</td>
                <td align="center">Hormat Kami, <?=ucwords(strtolower('PT. Airlangga sentral internasional asia'))?><br><br><br><br></td>
            </tr>
            <tr>
                <td align="center"><?=ucwords(strtolower($key['nama_pembeli']))?></td>    
                <td align="center"><?=ucwords(strtolower('riza putri agustina, S.Farm,. Apt'))?>
                    <br><small><?=''//$key['no_apoteker']?></small>
                </td>

            </tr>
        </table>
        </tr>
        <?php
        }?>
</table>
</body>